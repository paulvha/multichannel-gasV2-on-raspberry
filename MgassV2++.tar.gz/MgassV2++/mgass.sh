# make Multichannel gas sensor V2
# Initial release January 2022 , Paul van Haastrecht.
gcc -Wall -o gass2 gass.cpp gass_lib.cpp -l bcm2835 -lm
