/* Multi channel gas sensor V2 user program
 *  
 * Copyright (c) 2022 Paul van Haastrecht <paulvha@hotmail.com>
 * 
 * Initial release January 2022.
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * The program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.  
 */

#include "gass.h"
#include "gass_lib.h"

char Progversion[] = "Version 1.1 / january 2022";

GAS_GMXXX gas;

// global variables

uint8_t slave_address_base = DEFAULT_I2C_ADDR; // current slave address
uint16_t loop_seconds = 5;       // time in seconds to wait in between show
int  NoColor = 0;                // disables color output (if set)
bool DisplayTimeStamp = false;   // add timestamp to output
bool DisplayCommaSep = false;    // output values comma separated
char CommaBuf[100];              // placeholder to comma separate
char tm[30];                     // working buffer
int  DEBUG = 0;                  // enable / disable debug messages   
   
/*********************************************************************
** Function name:           hw_init
** Descriptions:            setup hardware 
**
** set the BCM2835 for I2c communication 
** return 0 = ok, else exit()
********************************************************************/
int hw_init() 
{
    int ret = gas.begin(slave_address_base);
    
    if (ret == -1) {
        p_printf(RED,"Can't init bcm2835!\n");
        exit(1);
    }
    else if (ret == -2) {
        p_printf(RED,"Can't setup i2c pin!\n");
        exit(1);
    }
    else if (ret == -3){
        p_printf(RED,"Can't start preheating!\n");
        exit(1);       
    }
    else {
        if (DEBUG) p_printf(GREEN,"Detected sensor on address 0x%x\n",slave_address_base);
    }
    
    return 0;
}

/*********************************************************************
** Function name:           time_stamp
** Descriptions:            generate timestamp
** @param buf : buffer to write
********************************************************************/ 
void time_stamp(char *buf)
{
    time_t ltime;
    struct tm *tm ;
    
    ltime = time(NULL);
    tm = localtime(&ltime);
    
    static const char wday_name[][4] = {
    "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
    
    static const char mon_name[][4] = {
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

    sprintf(buf, "%.3s %.3s%3d %.2d:%.2d:%.2d %d",
    wday_name[tm->tm_wday],  mon_name[tm->tm_mon],
    tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec,
    1900 + tm->tm_year);
}


/*********************************************************************
** Function name:           changeI2cAddr
** Descriptions:            Update the I2C address
**
********************************************************************/
void changeI2cAddr(uint8_t newA)
{
    if (gas.changeGMXXXAddr(newA) == -1)
    {
        p_printf(RED,"Error during changing address\n");
        return;
    }

    slave_address_base = newA;
}

/* end the program correctly */
void close_out(int end)
{
    // close I2C connection
    gas.end();

    // exit with return code
    exit(end);
}

/**********************************************************************
** Function name:           p_printf
** Descriptions:            display messages
**
** @param format : Message to display & optional arguments (as printf)
** @param level :  RED, GREEN, YELLOW, BLUE  or WHITE
** 
**  if NoColor was set, output is always WHITE.
***********************************************************************/

void p_printf (int level, const char * format, ...)
{
    char    *col;
    int     coll=level;
    va_list arg;
    
    //allocate memory
    col = (char *) malloc(strlen(format) + 20);
    
    if (NoColor) coll = WHITE;
                
    switch(coll)
    {
        case RED:
            sprintf(col,REDSTR, format);
            break;
        case GREEN:
            sprintf(col,GRNSTR, format);
            break;      
        case YELLOW:
            sprintf(col,YLWSTR, format);
            break;      
        case BLUE:
            sprintf(col,BLUSTR, format);
            break;
        default:
            sprintf(col,"%s",format);
    }

    va_start (arg, format);
    vfprintf (stdout, col, arg);
    va_end (arg);

    fflush(stdout);

    // release memory
    free(col);
}

/*********************************************************************
** catch signals to close out correctly 
**********************************************************************/
void signal_handler(int sig_num)
{
    switch(sig_num)
    {
        case SIGKILL:
        case SIGABRT:
        case SIGINT:
        case SIGTERM:
            p_printf(YELLOW, "\nStopping Multichannel gas_sensor reader.\n");
            close_out(2);
            break;
        default:
            p_printf(RED,"\nneglecting signal %d.\n",sig_num);
    }
}

/*********************************************************************
** setup signals 
**********************************************************************/
void set_signals()
{
    struct sigaction act;
    
    memset(&act, 0x0,sizeof(act));
    act.sa_handler = &signal_handler;
    sigemptyset(&act.sa_mask);
    
    sigaction(SIGTERM,&act, NULL);
    sigaction(SIGINT,&act, NULL);
    sigaction(SIGABRT,&act, NULL);
    sigaction(SIGSEGV,&act, NULL);
    sigaction(SIGKILL,&act, NULL);
}

/*********************************************************************
** Function name:           usage
** Descriptions:            display usage / command line information
** @param name : name of program
**
**********************************************************************/
void usage(char *name)
{
    p_printf(YELLOW,"%s \n"
    "\n%s\n"
    "Copyright (c)  2022 Paul van Haastrecht\n"
    "\n"
    "-a #,  Change I2C address to #.\n"
    "-d,    Enable debug messages.\n"
    "-h,    Show this help text.\n"


    "\nDisplay commands\n"
    "-c,    Output as comma separated\n"
    "-l #,  Loop time for reading to # seconds. (default %d seconds)\n"
    "-n,    No colored output.\n"
    "-s #,  Get sensor values # times.\n"
    "-t,    add timestamp to output.\n"
    "-v,    Display library version.\n\n",
    name, Progversion, loop_seconds);
}

/*********************************************************************
** Function name:           display_version
** Descriptions:            display Library version
**
**********************************************************************/
void display_version()
{
    p_printf(YELLOW,"Library Version %s\n",gas.getLibVersion());
}

/*******************************************************************
** Function name:           display_VOC
** Descriptions:            display VOC
** @param C : Voc
* 
*********************************************************************/
void display_VOC(uint32_t c)
{
    float level;
    
    if (c < 0)
    {
        p_printf(RED, "\nInvalid concentration for VOC\n"); 
        return;
    }
    else if (c == 0)
    {
        p_printf(YELLOW, "\nRatio out of range for VOC\n"); 
        return; 
    }
    
    if (DisplayCommaSep) {
        sprintf(tm, ",%d", c);
        strcat(CommaBuf,tm);
        return;
    }
        
    level = gas.calcVol(c);
    
    p_printf(GREEN, "\nThe concentration of Methane is %d or %3.2f V\n", c,level);
}

/********************************************************************
** Function name:           display_C2H5H
** Descriptions:            display Ethanol
** @param C : Ethanol 
* 
*********************************************************************/
void display_C2H50H(uint32_t c)
{
    float level;
    
    if (c < 0)
    {
        p_printf(RED, "\nInvalid concentration for C2H5OH (Ethanol) \n");   
        return;
    }
    else if (c == 0)
    {
        p_printf(YELLOW, "\nRatio out of range for Ethanol\n"); 
        return; 
    }
    
    if (DisplayCommaSep) {
        sprintf(tm, ",%d", c);
        strcat(CommaBuf,tm);
        return;
    }
 
    level = gas.calcVol(c);
    
    p_printf(GREEN, "\nThe concentration of C2H5OH (Ethanol) is %d or %3.2f V\n", c,level);
}

/******************************************************************
** Function name:           display_CO
** Descriptions:            display carbon monoxide
** @param C : ADC CO
* 
**********************************************************************/
void display_CO(uint32_t c)
{
    float level;
    
    if (c < 0)
    {
        p_printf(RED, "\nInvalid concentration for CO (Carbon Monoxide)\n");    
        return;
    }
    else if (c == 0)
    {
        p_printf(YELLOW, "\nRatio out of range for Carbon Monoxide\n"); 
        return; 
    }
    
    if (DisplayCommaSep) {
        sprintf(tm, ",%d", c);
        strcat(CommaBuf,tm);
        return;
    }
        
    level = gas.calcVol(c);
    
    p_printf(GREEN, "\nThe concentration of CO (Carbon Monoxide) is %d or %3.2f V\n", c,level);
}

/******************************************************************
** Function name:           display_NO2
** Descriptions:            display  Nitrogen Dioxide
** @param C : ADC NO2
**
*********************************************************************/
void display_NO2(uint32_t c)
{
    float level;
    
    if (c < 0)
    {
        p_printf(RED, "\nInvalid concentration for NO2 (Nitrogen Dioxide)\n");  
        return;
    }
    else if (c == 0)
    {
        p_printf(YELLOW, "\nRatio out of range for Nitrogen Dioxide\n");    
        return; 
    }
    
    if (DisplayCommaSep) {
        sprintf(tm, ",%d", c);
        strcat(CommaBuf,tm);
        return;
    }
        
    level = gas.calcVol(c);
    
    p_printf(GREEN, "\nThe concentration of NO2 (Nitrogen Dioxide) is %3d or %3.2f V\n\t", c,level);
}

/********************************************************************
** Function name:           display_senor_value
** Descriptions:            display all possible sensor values
** @param lp : amount of loops to display the sensors
**
*********************************************************************/
void display_sensor_value(int lp)
{
    uint32_t c;
    static   bool header = true;

    while (lp -- != 0)
    {
        if (DisplayTimeStamp) {
            
            // get timestamp
            time_stamp(tm);
            
            // output comma seperated
            if (DisplayCommaSep) {                      
                
                if (header) {
                    strcpy(CommaBuf, "timestamp,NO2,C2H50H,VOC,CO\n");
                    strcat(CommaBuf,tm);
                    header = false;
                }
                else {
                    strcpy(CommaBuf,tm);
                }
            }
            else {
                p_printf(GREEN, "%s\n", tm);
            }
        }
        
        if ((c = gas.measure_NO2()) > 0)  display_NO2(c);
        else
            p_printf(RED, "Invalid concentration for NO2\n");
    
        if ((c = gas.measure_C2H50H()) >0) display_C2H50H(c);
        else
            p_printf(RED, "Invalid concentration for C2H50H)\n");
    
        if ((c = gas.measure_VOC()) > 0) display_VOC(c);
        else
            p_printf(RED, "Invalid concentration for VOC\n");
    
        if ((c = gas.measure_CO()) > 0) display_CO(c);
        else
            p_printf(RED, "Invalid concentration for CO\n");
        
        if (DisplayCommaSep) {
            p_printf(GREEN,"%s\n", CommaBuf);
        }
        
        // only if not last
        if (lp > 0)
        {   
            if (DEBUG) p_printf(YELLOW,"wait %d seconds\n", loop_seconds);
        
            sleep(loop_seconds);
        }
    } 
}
    
int main(int argc, char *argv[])
{
    int c ;
    uint8_t i2cadd = 0;
    uint8_t sense;
    
    if (geteuid() != 0){
        p_printf(RED,"Must be run as root.\n");
        exit(-1);
    }

    // catch signals
    set_signals();

    while (1)
    {
        c = getopt(argc, argv,"-a:cdvhl:ns:t");

        if (c == -1)    break;
    
        switch (c) {
            case 'd':   // set debug level
                DEBUG = 1;
                break;
            
            case 'a':   // change i2C address
                i2cadd = (uint8_t) strtod(optarg, NULL);
                if (i2cadd > 127)
                {
                    p_printf(RED,"Invalid I2C address. Ignored\n");
                    i2cadd = 0;
                }
                break;

            case 'c':   // comma separated output
                DisplayCommaSep = true;
                break;
                            
            case 'v':   // library version
                display_version();
                break;
            
            case 'l':   // change loop time
                loop_seconds = (uint16_t) strtod(optarg, NULL);
                
                if (loop_seconds > 600)
                {
                    p_printf(RED,"Maximum value is 600 seconds. Ignored\n");
                    loop_seconds = 5;
                }
                else if (loop_seconds < 2)
                {
                    p_printf(RED,"Minimum value is 2 seconds. Ignored\n");
                    loop_seconds = 5;
                }
                break;
            
            case 'n':   // no color in output
                NoColor=1;
                break;
            
            case 's':   // sensor values
                sense = (int) strtod(optarg, NULL);
                break;
                
            case 't':   // add timestamp
                DisplayTimeStamp = true;
                break;

            case 'h':
            default:    // display help
                usage(argv[0]);
                exit(0); 
                break;
        }
    
    }
    
    gas.SetDebug(DEBUG); 
    
    // initialize hardware
    if (hw_init() != 0 ) exit(-1);
    
    // call functions
    if (i2cadd) changeI2cAddr(i2cadd);
    if (sense)  display_sensor_value(sense);
        
    close_out(0);
    
    return 0;
}
