/*  Multi channel gas sensor V2 access library

    Large parts are based on the original library for Arduino

    more info on:

    https://wiki.seeedstudio.com/Grove-Multichannel-Gas-Sensor-V2

    Based on :

    Multichannel_Gas_GMXXX.cpp
    Description : A drive for Seeed Grove Multichannel gas Sensor V2

    2019 Copyright (c) Seeed Technology Inc.  All right reserved.
    Author: Hongtai Liu (lht856@foxmail.com)
    2019-6-18

    The MIT License (MIT)
    Copyright (c) 2015 Seeed Technology Inc.
    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:
    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    THE SOFTWARE.

    Version 1.0 / Paul van Haastrecht <paulvha@hotmail.com>
    Initial release for Raspberry Pi. January 2022.

   WHERE NEEDED THE ORIGINAL LIBRARY WAS CHANGED TO WORK BETTER ON A RASPBERRY PI
 */

#include "gass_lib.h"

char version[] = "1.1 / january 2022";

GAS_GMXXX::GAS_GMXXX()
{
}

GAS_GMXXX::~GAS_GMXXX()
{
}

/*********************************************************************
** Function name:           Begin
** Descriptions:            setup hardware 
**
** set the BCM2835 for I2c communication 
** return 
*  0 = ok,
* -1 = can't init BCM2835
* -2 = can't begin
* -3 = cant find sensor
********************************************************************/
int GAS_GMXXX::begin(uint8_t address)
{
    if (! bcm2835_init()) return(-1);

    // will select I2C channel 0 or 1 depending on board reversion.
    if (! bcm2835_i2c_begin()){
        
        // release BCM2835 library
        bcm2835_close(); 
        
        return(-2);
    }
    
    SetAddress(address);
    
    /* set BSC speed to 100Khz*/
    bcm2835_i2c_setClockDivider(BCM2835_I2C_CLOCK_DIVIDER_2500);
    
    /* Start preheating the gas sensor*/
    if (preheated() != 0 ) {
        // release BCM2835 library
        bcm2835_close();
        
        return(-3);
    }
    
    return(0);
}


/**********************************************************************
** Function name:           end
** Descriptions:            close connection
***********************************************************************/
void GAS_GMXXX::end()
{
    // reset pins (uncomment MIGHT conflict with other program using I2C)
    //bcm2835_i2c_end();    
    
    // release BCM2835 library
    bcm2835_close();
}

/**********************************************************************
** Function name:           getLibVersion
** Descriptions:            return library version
***********************************************************************/
char * GAS_GMXXX::getLibVersion()
{
    return version;
}

/*********************************************************************
 * start heating the sensor
 *
 * return 0 if OK else -1
 *********************************************************************/
int GAS_GMXXX::preheated()
{
    char c = WARMING_UP;

    if (write_gass(&c,1) != 0){
        if(DEBUG_LIB) printf(GREDSTR,"DEBUG: preheated failed\n");
        return (-1);
    }

    isPreheated = true;

    return 0;
}

/*********************************************************************
 * stop heating the sensor
 *
 * return 0 if OK else -1
 *********************************************************************/
int GAS_GMXXX::unPreheated()
{
    char c = WARMING_DOWN;

    if (write_gass(&c,1) != 0){
        if(DEBUG_LIB) printf(GREDSTR,"DEBUG: UnPreheated failed\n");
        return (-1);
    }

    isPreheated = false;

    return 0;
}

/*********************************************************************
 * get the ADC value for a gas
 *
 * @param g : type of gas
 *
 * return value if OK else 0
 *********************************************************************/
uint32_t GAS_GMXXX::getGas(char g)
{
    dta_buf[0] = g;

    if (! isPreheated) {

        if (preheated() != 0) 
            return 0;
    }

    if (write_gass(dta_buf,1) != 0) {
        return 0;
    }

    if (read_gass(dta_buf,4) != 0) {
        if(DEBUG_LIB) printf(GREDSTR,"DEBUG: read gas value failed\n");
        return 0;
    }

    uint32_t ret = ((uint32_t) dta_buf[0] +((uint32_t) dta_buf[1] << 8) + \
		    ((uint32_t) dta_buf[2] << 16) + ((uint32_t) dta_buf[3] << 24));
    
    return ret;
}

/*********************************************************************
 * calculate volume for a gas
 *
 * @param adc : ADC value read with getGas()
 *
 *********************************************************************/
float GAS_GMXXX::calcVol(uint32_t adc)
{
    return ((float) ((adc * 3.3) / GM_RESOLUTION));
}

/**********************************************************************
** Function name:           write_gass
** Descriptions:            write to gass sensor the amount of bytes
**
** @param buf : data to be sent
** @param cnt : the amount of characters
**
** return code
**  0 = OK
** -1 = Error
**********************************************************************/
int GAS_GMXXX::write_gass(char *buf, int cnt)
{ 
    // write
    switch(bcm2835_i2c_write(buf,cnt))
    {
        case BCM2835_I2C_REASON_ERROR_NACK :
            if(DEBUG_LIB) printf(GREDSTR,"DEBUG: Write NACK error\n");
            return(-1);
            break;

        case BCM2835_I2C_REASON_ERROR_CLKT :
            if(DEBUG_LIB) printf(GREDSTR,"DEBUG: Write Clock stretch error\n");
            return(-1);
            break;

        case BCM2835_I2C_REASON_ERROR_DATA :
            if(DEBUG_LIB) printf(GREDSTR,"DEBUG: not all data has been written\n");
            return(-1);
            break;
    }

    //give time to settle
    usleep(500);

    return 0;
}

/**********************************************************************
** Function name:           read_gass
** Descriptions:            read from gass sensor the amount of bytes
**
** @param buf : store data read
** @param cnt : amount of characters
**
** return code
**  0 = OK
** -1 = Error
**********************************************************************/
int GAS_GMXXX::read_gass(char *buf, int cnt)
{
    switch(bcm2835_i2c_read(buf, cnt))
    {
        case BCM2835_I2C_REASON_ERROR_NACK :
            if(DEBUG_LIB) printf(GREDSTR,"DEBUG: Read NACK error\n");
            return(-1);
            break;

        case BCM2835_I2C_REASON_ERROR_CLKT :
            if(DEBUG_LIB) printf(GREDSTR,"DEBUG: Read Clock stretch error\n");
            return(-1);
            break;

        case BCM2835_I2C_REASON_ERROR_DATA :
            if(DEBUG_LIB) printf(GREDSTR,"DEBUG: not all data has been read\n");
            return(-1);
            break;
    }

    return 0;
}

/**********************************************************************
** Function name:           changeGMXXXAddr
** Descriptions:            Change the I2C address
**
** @param newAddr 	new I2C address
** returns:         0 = ok, -1 error
**********************************************************************/
int GAS_GMXXX::changeGMXXXAddr(uint8_t newAddr)
{
    dta_buf[0] = CHANGE_I2C_ADDR;
    dta_buf[1] = newAddr;

    if (write_gass(dta_buf, 2) < 0)
    {
        printf("could not update to new address %d\n", newAddr);
        return(-1);
    }

    /* set NEW slave address for gas sensor*/
    bcm2835_i2c_setSlaveAddress(newAddr);

    // give gas sensor processor time to settle
    sleep(1);

    return(preheated());
}

/*********************************************************************
 * Set I2C address to use
 *
 *********************************************************************/
void GAS_GMXXX::SetAddress(uint8_t addr)
{
    GMXXX_Address = addr;

    /* set slave address for gas sensor*/
    bcm2835_i2c_setSlaveAddress(GMXXX_Address);
}

/*********************************************************************
 * enable / disable debug messages
 *
 *********************************************************************/
void GAS_GMXXX::SetDebug(int d)
{
    DEBUG_LIB = d;
}
