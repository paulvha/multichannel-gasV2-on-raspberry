/* header file for Multichannel gas_sensor V2 user program
 * 
 * Copyright (c) 2022 Paul van Haastrecht <paulvha@hotmail.com>
 *
 * Initial release January 2022.
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * The program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.  
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <stdarg.h>
#include <time.h>

/* display color */
#define RED 	1
#define GREEN 	2
#define YELLOW  3
#define BLUE	4
#define WHITE	5

#define REDSTR "\e[1;31m%s\e[00m"
#define GRNSTR "\e[1;92m%s\e[00m"
#define YLWSTR "\e[1;93m%s\e[00m"
#define BLUSTR "\e[1;34m%s\e[00m"

/********************************************************************
** All functions in gass.cpp
*********************************************************************/
    
/* setup hardware  
 * set the BCM2835 for I2c communication 
 * return 0 = ok, -1 = error*/
int hw_init();

/* end the program correctly */
void close_out(int end);

/* change address */
void changeI2cAddr(uint8_t newA);

/* setup signals */
void set_signals();
void signal_handler(int sig_num);

//generate timestamp
void time_stamp(char *buf);

/******************************************************
 ** display routines
 ******************************************************/

/* display message in color
 * @param format : message to display and optional arguments
 *                 same as printf
 * @param color :  RED, GREEN, YELLOW, BLUE, WHITE
 * 
 */
void p_printf (int level, const char *format, ...);

/* display current library level */
void display_version();

/* display gas information */
void display_sensor_value(int lp);

/* display functions for different gas-types */
void display_C2H5H(uint32_t c);
void display_VOC(uint32_t c);
void display_CO(uint32_t c);
void display_NO2(uint32_t c);

/* display usage information */
void usage(char *name);
