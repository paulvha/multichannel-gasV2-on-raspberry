/* Mulitchannel gas sensor V2 access library 
  
    Large parts are based on the original library for Arduino 
  
  
    Based on :
        
    Multichannel_Gas_GMXXX.cpp
    Description : A drive for Seeed Grove Multichannel gas Sensor V2
 
    2019 Copyright (c) Seeed Technology Inc.  All right reserved.
    Author: Hongtai Liu (lht856@foxmail.com)
    2019-6-18

    The MIT License (MIT)
    Copyright (c) 2015 Seeed Technology Inc.
    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:
    The above copyright notice and this permission notice shall be included in
    all copies or substantial portions of the Software.
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
    THE SOFTWARE.
 
    Version 1.0 / January 2022 / paulvha
    
    more info on:
      
    https://wiki.seeedstudio.com/Grove-Multichannel-Gas-Sensor-V2
  */
  
#ifndef _GAS_GMXXX_
#define _GAS_GMXXX_

/********************************************************************
** Variables for the Multi Gas sensor v2
*********************************************************************/
#define DEFAULT_I2C_ADDR 0x08

#define GM_102B  0x01
#define GM_302B  0x03
#define GM_502B  0x05
#define GM_702B  0x07

#define CHANGE_I2C_ADDR  0X55
#define WARMING_UP  0XFE
#define WARMING_DOWN  0XFF
#define GM_RESOLUTION  1023

/********************************************************************
** All functions in gassV2_lib.c
*********************************************************************/

int preheated();
int unPreheated();
int changeGMXXXAddr(uint8_t address);
void SetAddress(uint8_t addr);
char *getLibVersion();
void SetDebug(int d);

uint32_t getGM102B();
uint32_t getGM302B();
uint32_t getGM502B();
uint32_t getGM702B();

uint32_t measure_NO2();
uint32_t measure_C2H50H();
uint32_t measure_VOC();
uint32_t measure_CO();

float calcVol(uint32_t adc);

// internal functions
uint32_t getGas(char g);
int read_gass(char *buf, int cnt);
int write_gass(char *buf, int cnt);

#endif
